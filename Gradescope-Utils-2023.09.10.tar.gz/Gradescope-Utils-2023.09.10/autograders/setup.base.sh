#!/usr/bin/env bash

apt install -y perl cpanminus
cpanm Carp::Assert
cpanm Text::CSV
cpanm JSON
